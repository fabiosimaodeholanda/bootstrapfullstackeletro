<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF8">
<title>Contato - Full Stack Eletro</title>
<link rel="Stylesheet" href="./css/estilo.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
    <nav class="menu">
        <a href="index.php"><img width="100px%" src="./imagens/logo.png" alt="Full Stack Eletro"/></a>
        <a href="produtos.php">Nossos produtos</a>
        <a href="loja.php">Nossas lojas</a>
        <a href="contato.php">Fale conosco</a>
        </nav>
<header>
<h2 style="text-align: center" class="text-primary bg-dark">Contato</h2>
</header>
<hr>

<table border="0" width="100%" cellpadding="20">
<tr>
<td width="50%" align="center">
<img src="./imagens/e-mail.png" width="40px">
<font face="Arial" size="4" class="text-warning">contato@fullstackeletro.com</font>
</td>

<td width="50%" align="center">
<img src="./imagens/zap.png" width="80px">
<font face="Arial" size="4" class="text-success">(11) 99999-9999</font>
</td>
</tr>
</table>
<form>
<h4 class="text-secondary">Nome:</h4>
<input type="text" class="form-control border border-primary" style="width: 400px">
<h4 class="text-secondary">Mensagem:</h4>
<textarea style="width: 400px"  class="form-control border border-primary"></textarea><br>
<input type="submit" class="btn btn-primary"  value="Enviar">
</form>
<br><br><br><br><br>
<br><br><br><br><br>
<br><br><br><br><br>
<footer id="rodape">
    <p id="formas_pagamento"><b>Formas de pagamento:</b></p>
    <img src="./imagens/formas-pagamento.png" style="width:30%" alt="formas de pagamento"/>
    <p>&copy; Recode Pro</p>
    </footer>
</body>